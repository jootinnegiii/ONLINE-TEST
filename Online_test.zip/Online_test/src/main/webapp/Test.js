console.log("1");
var choose=false;

var number=0;
let qno=0;
qno=document.getElementById("qnoo").innerHTML;
console.log("q"+qno);
for(var i=1;i<=4;i++){
    var c=document.getElementById(i)
    c.style.backgroundColor="#eee";
    document.getElementById('c'+i).checked = false;
    }

    var checkColor="#2196F3";


    setcolor(0,false);
time="05:10"
if(document.getElementById('sec1').innerHTML=="Physics")
time="15:00";
else if(document.getElementById('sec1').innerHTML=="Aptitude")
time="10:00";
if(qno==1)
{
    document.getElementById("bbtn").style.marginLeft="-300px";
    //document.getElementById("prev").style.visibility = 'hidden';
  
      document.getElementById("prev").disabled='block';
 hiide("prev");
  // document.getElementById("prev").style.visibility = 'hidden';

  

}
if(qno==5)
{
    
    document.getElementById("bbtn").style.marginLeft="320px";
document.getElementById("nex").disabled='block';
hiide("nex");
}
prev_resonse();
 function prev_resonse()
{
	var n_ans=5,ans=0,doubt=0;
	
	
	if(localStorage.getItem('ans')!=null)
    {
       let ansObj=JSON.parse(localStorage.getItem('ans'));

if(localStorage.getItem('marks')!=null)
	{
		let marObj=JSON.parse(localStorage.getItem('marks'));
		number=marObj[qno-1];
   for(var c=0;c<5;c++)
{
	if(marObj[c]=='1')
	{
	  doubt++;
	}
	if(marObj[c]=='2'||ansObj[c+1]>0){
		console.log("ans"+ans);
	    ans++;
}
}
console.log("ans"+ans);
document.getElementById("not_ans").innerHTML=(5-ans);
document.getElementById("marked").innerHTML=(ans);
document.getElementById("doubt").innerHTML=(doubt);
    
	}
   if(ansObj[qno]>0){
	choose=true;
	
	console.log('check'+(ansObj[qno]));
       let chec= document.getElementById(ansObj[qno]);
        chec.style.backgroundColor=checkColor;
}
   }
}
function hiide(qqq)
{
	document.getElementById(qqq).style.opacity=0;
}
//getans(0);

var a=document.getElementById("one");
a.addEventListener('click',function(e)
{
    choose=true;
number=2;

  document.getElementById('q'+qno).style.backgroundColor="greenyellow";
   for(var i=1;i<=4;i++){
   var c=document.getElementById(i)
   c.style.backgroundColor="#eee";
   document.getElementById('c'+i).checked = false;
   }
   document.getElementById('c1').checked = true;
   c=document.getElementById(1)
   getans(1);
   c.style.backgroundColor=checkColor;
 setcolor(qnoo-1,true);
 
});
var a=document.getElementById("two");
a.addEventListener('click',function(e)
{getans(2);
number=2;
 document.getElementById('q'+qno).style.backgroundColor="greenyellow";
    choose=true;
   for(var i=1;i<=4;i++){
   var c=document.getElementById(i)
   c.style.backgroundColor="#eee";
   document.getElementById('c'+i).checked = false;
   }
   document.getElementById('c2').checked = true;
   c=document.getElementById(2)
   c.style.backgroundColor=checkColor;
 setcolor(qnoo-1,true);
});
var a=document.getElementById("three");
a.addEventListener('click',function(e)
{
    getans(3);
     document.getElementById('q'+qno).style.backgroundColor="greenyellow";
    choose=true;number=2;
   for(var i=1;i<=4;i++){
   var c=document.getElementById(i)
   c.style.backgroundColor="#eee";
   document.getElementById('c'+i).checked = false;
   }
   document.getElementById('c3').checked = true;
   c=document.getElementById(3)
   c.style.backgroundColor=checkColor;
 setcolor(qnoo-1,true);
});
var a=document.getElementById("four");
a.addEventListener('click',function(e)
{getans(4);
    choose=true;
number=2;
 document.getElementById('q'+qno).style.backgroundColor="greenyellow";
   for(var i=1;i<=4;i++){
   var c=document.getElementById(i)
   c.style.backgroundColor="#eee";
   document.getElementById('c'+i).checked = false;
   }
   c=document.getElementById(4)
   c.style.backgroundColor=checkColor;
   document.getElementById('c4').checked = true;
 setcolor(qnoo-1,true);
});
var flagg=true;
function flag(q)
{
    document.getElementById(q).style.backgroundColor="red"
    number=1;
    flagg=false;
}
function unflag(q)
{
    
    if(flagg==false)
     document.getElementById(q).style.backgroundColor="grey";
     number=0;
     flagg=true;
}
function next(q)
{
    if(choose==true)
    document.getElementById('q'+q).style.backgroundColor="greenyellow";
    
    setcolor(q,true);
}
function cleann(id)
{
    for(var i=1;i<=4;i++){
        var c=document.getElementById(i)
        c.style.backgroundColor="#eee";
        document.getElementById('c'+i).checked = false;
        }
        choose=false;
        number=0;
        document.getElementById(id).style.backgroundColor= "aliceblue";
}
function setcolor(page,boolf){
let marks=localStorage.getItem('marks');
if(marks==null)
 marksObj=[0,0,0,0,0,0,0,0];
 else
 marksObj=JSON.parse(marks);
 if(boolf)
    marksObj[page-1]=number;
   console.log("m"+marksObj);
 for(var as=0;as<5;as++)
 {
	
     if(marksObj[as]==0)
     document.getElementById('q'+(as+1)).style.backgroundColor= "aliceblue";
   else  if(marksObj[as]==1)
     document.getElementById('q'+(as+1)).style.backgroundColor= "red";
      else if(marksObj[as]==2||ansObj[qno]>0)
      document.getElementById('q'+(as+1)).style.backgroundColor= "greenyellow";


 }

 localStorage.setItem('marks',JSON.stringify(marksObj));
}
function getans(a)
{
    let ans=localStorage.getItem('ans');
    let ansObj;
    console.log("heelo");
    if(ans==null)
       ansObj=[0,0,0,0,0,0,0,0];
       else
       ansObj=JSON.parse(ans);
    ansObj[qno]=a;
   // console.log(ansObj);
    localStorage.setItem('ans',JSON.stringify(ansObj));
}
function submans()
{

    var v=localStorage.getItem('ans');
   
    console.log(v);
var url="ans.java?val="+v;
const request=new  XMLHttpRequest();
  
request.open("GET",url,false); 
request.onload=function()
{
	if(this.status==200)
	{
		console.log("ready to go");
		
	}
	else
	console.log("error");
} 
request.send();  

if(localStorage.getItem('ans2')!=null)
   submans2();
if(localStorage.getItem('ans3')!=null)
   submans3();
}
function submans2()
{

    var v=localStorage.getItem('ans2');
   
    console.log(v);
var url="ans2.java?val="+v;
const request=new  XMLHttpRequest();
  
request.open("GET",url,false); 
request.onload=function()
{
	if(this.status==200)
	{
		console.log("ready to go");
		
	}
	else
	console.log("error");
} 
request.send();
}
function submans3()
{

    var v=localStorage.getItem('ans3');
   
    console.log(v);
var url="ans3.java?val="+v;
const request=new  XMLHttpRequest();
  
request.open("GET",url,false); 
request.onload=function()
{
	if(this.status==200)
	{
		console.log("ready to go");
		
	}
	else
	console.log("error");
} 
request.send();
}

document.getElementById('demo').innerHTML =
  time;
  if(qno==1&&localStorage.getItem("time")==null)
 localStorage.setItem("time",time);
 startTimer();


function startTimer() {
  var presentTime = localStorage.getItem("time");
  
  var timeArray = presentTime.split(/[:]+/);
  var m = timeArray[0];
  var s = checkSecond((timeArray[1] - 1));
  if(s==59){m=m-1}
  if(m<0){
    return
  }
  
  document.getElementById('demo').innerHTML =
    m + ":" + s;
  var tt=m + ":" + s;
  if(m==0&&s==0){
  
  window.location.href = "TimeOut.jsp";
  }
  if(m<1)
    document.getElementById('tt1').style.backgroundColor="red";
  localStorage.setItem("time",tt);
  console.log(m)
  setTimeout(startTimer, 1000);
  
}

function checkSecond(sec) {
  if (sec < 10 && sec >= 0) {sec = "0" + sec}; // add zero in front of numbers < 10
  if (sec < 0) {sec = "59"};
  return sec;
}
  //previous responce check
 
    