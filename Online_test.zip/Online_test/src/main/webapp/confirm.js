function submans()
{
    var v=localStorage.getItem('ans');
console.log(v);
   ansObj=JSON.parse(v);
var v1="";
for(var i=1;i<ansObj.length;i++)
  v1+=ansObj[i];

console.log(v1);
var url="AnsView.jsp?val1="+v1;

const request=new  XMLHttpRequest();
  
request.open("GET",url,true); 
request.onload=function()
{
	if(this.status==200)
	{
		console.log("ready to go");
		
	}
	else
	console.log("error");
} 
request.send(true);  
if(localStorage.getItem('ans2')!=null)
  submans2();
if(localStorage.getItem('ans3')!=null)
  submans3();
}
function submans2()
{
    var v=localStorage.getItem('ans2');
console.log(v);
   ansObj=JSON.parse(v);
var v1="";
for(var i=1;i<ansObj.length;i++)
  v1+=ansObj[i];

console.log(v1);
var url="AnsView.jsp?val2="+v1;

const request=new  XMLHttpRequest();
  
request.open("GET",url,true); 
request.onload=function()
{
	if(this.status==200)
	{
		console.log("ready to go");
		
	}
	else
	console.log("error");
} 
request.send(true);  

}
function submans3()
{
    var v=localStorage.getItem('ans3');
console.log(v);
   ansObj=JSON.parse(v);
var v1="";
for(var i=1;i<ansObj.length;i++)
  v1+=ansObj[i];

console.log(v1);
var url="AnsView.jsp?val3="+v1;

const request=new  XMLHttpRequest();
  
request.open("GET",url,true); 
request.onload=function()
{
	if(this.status==200)
	{
		console.log("ready to go");
		
	}
	else
	console.log("error");
} 
request.send(true);  

}
document.getElementById("yes").addEventListener("click",function(e)
{
	localStorage.clear();
});