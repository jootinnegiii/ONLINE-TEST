package com.helper;

public class Time extends Thread {
	  public Time()
	  {
		  
	  }
	    public int s=0,m=0;
	    public void  run()
	    {
	        while(true) {
	               s++;
	               if(s==60)
	               {
	                   m++;
	                   s=0;
	               }
	            System.out.println(m+":"+s);
	            try {
	                Thread.sleep(1000);
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	        }
	    }
	    public int sec()
	    {
	    	return s;
	    }
	    public  int mint()
	    {
	    	return m;
	    }
	}

