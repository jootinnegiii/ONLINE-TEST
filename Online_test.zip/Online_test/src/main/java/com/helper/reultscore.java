package com.helper;

public class reultscore {
String yourans;
String correctans;
String color;
public String getYourans() {
	return yourans;
}
public void setYourans(String yourans) {
	this.yourans = yourans;
}
public String getCorrectans() {
	return correctans;
}
public void setCorrectans(String correctans) {
	this.correctans = correctans;
}
public String getColor() {
	return color;
}
public void setColor(String color) {
	this.color = color;
}

}
