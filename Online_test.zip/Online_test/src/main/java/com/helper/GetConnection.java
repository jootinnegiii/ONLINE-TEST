package com.helper;
import java.sql.Connection;
import java.sql.DriverManager;
public class GetConnection {
	public Connection con=null;
	public Connection getConnection() {
		try {
			//Class.forName("com.mysql.jdbc.Drive");
			System.out.println("f");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/exam","root","ash12345");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("false");
		}
		return con;
	}
}
