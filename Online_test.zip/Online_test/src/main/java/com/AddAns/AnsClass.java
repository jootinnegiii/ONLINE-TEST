package com.AddAns;

public class AnsClass {
  private static int a[]=new int[10];
  private static int a2[]=new int[10];
  private static int a3[]=new int[10];
  public static void addAns(String s)
  {
	  for(int i=0;i<s.length();i++) {
		  a[i+1]=s.charAt(i)-'0';
	  System.out.println("aa"+a[i+1]);
	  }
  }

  public static int getAns(int i)
  {
	  return a[i];
  }
  public static void addAns2(String s)
  {
	  for(int i=0;i<s.length();i++) {
		  a2[i+1]=s.charAt(i)-'0';
	  System.out.println("aa2"+a2[i+1]);
	  }
  }

  public static int getAns2(int i)
  {
	  return a2[i];
  }
  public static void addAns3(String s)
  {
	  for(int i=0;i<s.length();i++) {
		  a3[i+1]=s.charAt(i)-'0';
	  System.out.println("aa"+a3[i+1]);
	  }
  }

  public static int getAns3(int i)
  {
	  return a3[i];
  }
}
